# gpg2 ssh authenticate
[[ -d ~/.gnupg ]] || ( gpg2 --list-secret-keys >/dev/null 2>&1 || : )
gpgconf --launch gpg-agent >/dev/null 2>&1
export SSH_AUTH_SOCK="$(gpgconf --list-dirs agent-ssh-socket)"
export GPG_TTY="$(tty)"
echo UPDATESTARTUPTTY | gpg-connect-agent >/dev/null 2>&1
# required for gpgv1
export GPG_AGENT_INFO="$(gpgconf --list-dirs agent-socket):0:1"    
# create sshcontrol file in ~/.gnupg/
[[ -f ~/.gnupg/sshcontrol ]] || ( ssh-add -L >/dev/null 2>&1 || : )
